package com.landrent.bot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        status = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
        }
        layout.addView(status)

        val settings = Button(this).apply {
            text = "Bedienungshilfe öffnen"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(settings)

        val test = Button(this).apply {
            text = "DIENST TESTEN"
            setOnClickListener {
                if (BotAccessibilityService.instance != null) {
                    status.text = "DIENST VERBUNDEN ✓"
                    Toast.makeText(this@MainActivity, "Dienst ist verbunden.", Toast.LENGTH_LONG).show()
                } else {
                    status.text = "DIENST NICHT VERBUNDEN"
                    Toast.makeText(this@MainActivity, "Dienst ist nicht verbunden.", Toast.LENGTH_LONG).show()
                }
            }
        }
        layout.addView(test)

        val start = Button(this).apply {
            text = "BOT STARTEN"
            setOnClickListener {
                BotAccessibilityService.instance?.startBot()
                    ?: Toast.makeText(this@MainActivity, "Dienst nicht verbunden.", Toast.LENGTH_LONG).show()
            }
        }
        layout.addView(start)

        val stop = Button(this).apply {
            text = "BOT STOPPEN"
            setOnClickListener { BotAccessibilityService.instance?.stopBot() }
        }
        layout.addView(stop)

        setContentView(layout)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        status.text = if (BotAccessibilityService.instance != null)
            "DIENST VERBUNDEN ✓"
        else
            "DIENST NICHT VERBUNDEN"
    }
}
