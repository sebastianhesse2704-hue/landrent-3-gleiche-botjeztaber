package com.landrent.bot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Toast.makeText(this, "LandRent Bot Dienst verbunden", Toast.LENGTH_LONG).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopBot()
    }

    fun startBot() {
        if (running) return
        running = true
        Toast.makeText(this, "Bot gestartet", Toast.LENGTH_SHORT).show()
    }

    fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        Toast.makeText(this, "Bot gestoppt", Toast.LENGTH_SHORT).show()
    }

    fun testTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        stopBot()
        instance = null
        super.onDestroy()
    }
}
