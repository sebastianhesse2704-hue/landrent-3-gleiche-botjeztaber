package com.landrent.mediabot2

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.widget.Toast

class CaptureService : Service() {
    companion object {
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastToast = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY

        val resultCode = intent?.getIntExtra("resultCode", -1) ?: -1
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("resultData", Intent::class.java)
        else
            @Suppress("DEPRECATION") intent?.getParcelableExtra<Intent>("resultData")

        if (resultCode != -1 && data != null) {
            startForeground(
                1001,
                Notification.Builder(this, "capture")
                    .setContentTitle("LandRent Bot")
                    .setContentText("Bildschirmzugriff aktiv")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .build()
            )
            startCapture(resultCode, data)
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val manager = getSystemService(MediaProjectionManager::class.java)
        projection = manager.getMediaProjection(resultCode, data)

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        reader!!.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bitmapWidth = width + rowPadding / pixelStride
                val bitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(plane.buffer)
                bitmap.recycle()

                val now = System.currentTimeMillis()
                if (now - lastToast > 3000) {
                    lastToast = now
                    Toast.makeText(
                        this,
                        "Bildschirm erfasst ✓  ${width}×${height}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (_: Exception) {
            } finally {
                image.close()
            }
        }, null)

        display = projection!!.createVirtualDisplay(
            "LandRentCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface,
            null,
            null
        )

        running = true
        Toast.makeText(this, "Bildschirmzugriff aktiv ✓", Toast.LENGTH_LONG).show()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "capture",
                "LandRent Bot",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        display?.release()
        reader?.close()
        projection?.stop()
        display = null
        reader = null
        projection = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
