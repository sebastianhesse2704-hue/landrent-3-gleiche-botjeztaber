plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.landrent.mediabot2"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.landrent.mediabot2"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
