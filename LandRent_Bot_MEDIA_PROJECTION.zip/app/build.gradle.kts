plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.landrent.mediabot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.landrent.mediabot"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
