package com.landrent.bot

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.hardware.HardwareBuffer
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var screenshotBusy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Toast.makeText(this, "Dienst verbunden ✓", Toast.LENGTH_LONG).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() = stopBot()

    fun startBot() {
        if (running) return
        running = true
        Toast.makeText(this, "Bot gestartet – Bildschirmtest läuft", Toast.LENGTH_LONG).show()
        testScreen()
    }

    fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        screenshotBusy = false
        Toast.makeText(this, "Bot gestoppt", Toast.LENGTH_SHORT).show()
    }

    private fun testScreen() {
        if (!running || screenshotBusy) return
        screenshotBusy = true

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bitmap: Bitmap? = null
                    var buffer: HardwareBuffer? = null
                    try {
                        buffer = result.hardwareBuffer
                        bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        val w = bitmap?.width ?: 0
                        val h = bitmap?.height ?: 0
                        Toast.makeText(
                            this@BotAccessibilityService,
                            "Bildschirm erkannt ✓  ${w}×${h}",
                            Toast.LENGTH_SHORT
                        ).show()
                    } catch (e: Exception) {
                        Toast.makeText(
                            this@BotAccessibilityService,
                            "Screenshot-Fehler: ${e.javaClass.simpleName}",
                            Toast.LENGTH_LONG
                        ).show()
                    } finally {
                        try { buffer?.close() } catch (_: Exception) {}
                        bitmap?.recycle()
                        screenshotBusy = false
                        if (running) handler.postDelayed({ testScreen() }, 2500)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    screenshotBusy = false
                    Toast.makeText(
                        this@BotAccessibilityService,
                        "Screenshot nicht möglich: Fehler $errorCode",
                        Toast.LENGTH_LONG
                    ).show()
                    if (running) handler.postDelayed({ testScreen() }, 3000)
                }
            }
        )
    }

    override fun onDestroy() {
        stopBot()
        instance = null
        super.onDestroy()
    }
}
