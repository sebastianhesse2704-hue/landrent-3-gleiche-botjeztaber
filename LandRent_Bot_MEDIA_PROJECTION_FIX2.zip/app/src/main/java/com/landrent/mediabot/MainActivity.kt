package com.landrent.mediabot2

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val projectionRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        status = TextView(this).apply {
            textSize = 19f
            gravity = Gravity.CENTER
            text = "Bereit"
        }
        layout.addView(status)

        val accessibility = Button(this).apply {
            text = "Bedienungshilfe öffnen"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(accessibility)

        val screen = Button(this).apply {
            text = "BILDSCHIRMZUGRIFF AKTIVIEREN"
            setOnClickListener { requestProjection() }
        }
        layout.addView(screen)

        val test = Button(this).apply {
            text = "BILDSCHIRM TESTEN"
            setOnClickListener {
                if (CaptureService.running) {
                    status.text = "BILDSCHIRMZUGRIFF AKTIV ✓"
                    Toast.makeText(this@MainActivity, "Bildschirmzugriff läuft.", Toast.LENGTH_LONG).show()
                } else {
                    status.text = "BILDSCHIRMZUGRIFF NICHT AKTIV"
                    Toast.makeText(this@MainActivity, "Bitte zuerst Bildschirmzugriff aktivieren.", Toast.LENGTH_LONG).show()
                }
            }
        }
        layout.addView(test)

        setContentView(layout)
    }

    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            // Keep the MediaProjection token in-process as well. Some Samsung builds
            // can lose the nested Intent when it is passed through a foreground-service
            // start Intent. The service reads these values before falling back to extras.
            CaptureService.pendingResultCode = resultCode
            CaptureService.pendingResultData = data

            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }
            startForegroundService(intent)
            status.text = "BILDSCHIRMZUGRIFF STARTET…"
        } else {
            status.text = "BILDSCHIRMZUGRIFF ABGEBROCHEN"
        }
    }
}
