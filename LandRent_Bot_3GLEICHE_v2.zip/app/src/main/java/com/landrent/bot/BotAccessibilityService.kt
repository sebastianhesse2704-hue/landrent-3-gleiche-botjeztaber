package com.landrent.bot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.hardware.HardwareBuffer
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var busy = false
    private var lastTapTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Toast.makeText(this, "LandRent Bot Dienst verbunden", Toast.LENGTH_LONG).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopBot() }

    fun startBot() {
        if (running) return
        running = true
        Toast.makeText(this, "Bot gestartet", Toast.LENGTH_SHORT).show()
        scheduleScan(700)
    }

    fun stopBot() {
        running = false
        busy = false
        handler.removeCallbacksAndMessages(null)
        Toast.makeText(this, "Bot gestoppt", Toast.LENGTH_SHORT).show()
    }

    private fun scheduleScan(delay: Long) {
        if (!running) return
        handler.postDelayed({ scanScreen() }, delay)
    }

    private fun scanScreen() {
        if (!running || busy) return
        busy = true

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bitmap: Bitmap? = null
                    try {
                        val buffer = result.hardwareBuffer
                        bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            ?.copy(Bitmap.Config.ARGB_8888, false)
                        buffer.close()
                        if (bitmap != null && running) {
                            val group = findTriple(bitmap)
                            if (group != null && System.currentTimeMillis() - lastTapTime > 700) {
                                tapTriple(group)
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        bitmap?.recycle()
                        busy = false
                        scheduleScan(if (running) 950 else 0)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    busy = false
                    scheduleScan(1500)
                }
            }
        )
    }

    private data class Tile(val x: Int, val y: Int, val feature: FloatArray)

    private fun findTriple(src: Bitmap): List<Tile>? {
        val w = src.width
        val h = src.height
        if (w < 400 || h < 700) return null

        // Board only: avoid the 7 tray slots and navigation/status areas.
        val yMin = (h * 0.27f).toInt()
        val yMax = (h * 0.82f).toInt()
        val step = max(8, w / 90)
        val radius = max(22, w / 18)

        val candidates = ArrayList<Tile>()
        val scores = ArrayList<FloatArray>()

        fun whiteScore(cx: Int, cy: Int): Float {
            var good = 0
            var total = 0
            val y0 = max(yMin, cy - radius)
            val y1 = min(yMax, cy + radius)
            val x0 = max(0, cx - radius)
            val x1 = min(w - 1, cx + radius)
            var y = y0
            while (y <= y1) {
                var x = x0
                while (x <= x1) {
                    val c = src.getPixel(x, y)
                    val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                    if (r > 165 && g > 165 && b > 165 && max(r, max(g, b)) - min(r, min(g, b)) < 55) good++
                    total++
                    x += 4
                }
                y += 4
            }
            return if (total == 0) 0f else good.toFloat() / total
        }

        val raw = ArrayList<Pair<Int,Int>>()
        var y = yMin + radius
        while (y < yMax - radius) {
            var x = radius
            while (x < w - radius) {
                val s = whiteScore(x, y)
                if (s >= 0.48f) raw.add(Pair(x, y))
                x += step
            }
            y += step
        }

        // Non-maximum suppression: one center per visible white tile.
        raw.sortByDescending { whiteScore(it.first, it.second) }
        for ((cx, cy) in raw) {
            if (candidates.none { dxdy(it.x, it.y, cx, cy) < radius * 1.15 }) {
                candidates.add(Tile(cx, cy, feature(src, cx, cy, radius)))
                if (candidates.size >= 30) break
            }
        }

        if (candidates.size < 3) return null

        // Find a conservative exact-looking triple. We compare the actual tile artwork,
        // not a hard-coded fruit list, so new symbols can also be handled.
        var best: List<Tile>? = null
        var bestScore = Float.MAX_VALUE

        for (i in candidates.indices) {
            for (j in i + 1 until candidates.size) {
                val d1 = featureDistance(candidates[i].feature, candidates[j].feature)
                if (d1 > 0.22f) continue
                for (k in j + 1 until candidates.size) {
                    val d2 = featureDistance(candidates[i].feature, candidates[k].feature)
                    val d3 = featureDistance(candidates[j].feature, candidates[k].feature)
                    val score = max(d1, max(d2, d3))
                    if (score < bestScore && score < 0.24f) {
                        bestScore = score
                        best = listOf(candidates[i], candidates[j], candidates[k])
                    }
                }
            }
        }
        return best
    }

    private fun dxdy(x1: Int, y1: Int, x2: Int, y2: Int): Float {
        val dx = (x1 - x2).toFloat()
        val dy = (y1 - y2).toFloat()
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    private fun feature(src: Bitmap, cx: Int, cy: Int, radius: Int): FloatArray {
        val n = 16
        val out = FloatArray(n * n * 3 + 12)
        var p = 0
        val size = radius * 2
        for (yy in 0 until n) {
            val sy = min(src.height - 1, max(0, cy - radius + yy * size / n))
            for (xx in 0 until n) {
                val sx = min(src.width - 1, max(0, cx - radius + xx * size / n))
                val c = src.getPixel(sx, sy)
                var r = Color.red(c) / 255f
                var g = Color.green(c) / 255f
                var b = Color.blue(c) / 255f
                // White tile background is normalized away.
                if (r > .72f && g > .72f && b > .72f) { r = 0f; g = 0f; b = 0f }
                out[p++] = r
                out[p++] = g
                out[p++] = b
            }
        }
        // Compact color histogram.
        var hp = n*n*3
        for (yy in 0 until n) {
            for (xx in 0 until n) {
                val base = (yy*n + xx)*3
                val r = out[base]; val g = out[base+1]; val b = out[base+2]
                val idx = (if (r > .55f) 4 else if (r > .25f) 2 else 0) +
                          (if (g > .55f) 1 else 0) +
                          (if (b > .55f) 2 else 0)
                out[hp + (idx % 12)] += 1f
            }
        }
        for (i in hp until out.size) out[i] /= (n*n).toFloat()
        return out
    }

    private fun featureDistance(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in 0 until 16*16*3) {
            val d = a[i] - b[i]
            sum += d*d
        }
        sum /= (16f*16f*3f)
        var hist = 0f
        for (i in 16*16*3 until a.size) hist += abs(a[i] - b[i])
        return sum * 0.75f + hist * 0.25f
    }

    private fun tapTriple(group: List<Tile>) {
        lastTapTime = System.currentTimeMillis()
        var delay = 0L
        for (tile in group) {
            handler.postDelayed({
                if (!running) return@postDelayed
                val path = Path().apply { moveTo(tile.x.toFloat(), tile.y.toFloat()) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
                    .build()
                dispatchGesture(gesture, null, null)
            }, delay)
            delay += 180L
        }
    }

    override fun onDestroy() {
        stopBot()
        instance = null
        super.onDestroy()
    }
}
